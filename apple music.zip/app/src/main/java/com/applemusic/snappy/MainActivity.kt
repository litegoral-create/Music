package com.applemusic.snappy

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ProgressBar
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar

    // Broadcast receiver to respond to lock screen and notification media actions
    private val mediaActionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                PlaybackMediaSessionService.ACTION_PLAY -> {
                    // Send Play command to web media session / audio
                    webView.evaluateJavascript(
                        "if (navigator.mediaSession && navigator.mediaSession.playbackState) { const a = document.querySelector('audio, video'); if (a) a.play(); }",
                        null
                    )
                }
                PlaybackMediaSessionService.ACTION_PAUSE -> {
                    // Send Pause command to web media session / audio
                    webView.evaluateJavascript(
                        "const a = document.querySelector('audio, video'); if (a) a.pause();",
                        null
                    )
                }
                PlaybackMediaSessionService.ACTION_NEXT -> {
                    webView.evaluateJavascript(
                        "if (window.__triggerNextTrack) { window.__triggerNextTrack(); }",
                        null
                    )
                }
                PlaybackMediaSessionService.ACTION_PREV -> {
                    webView.evaluateJavascript(
                        "if (window.__triggerPrevTrack) { window.__triggerPrevTrack(); }",
                        null
                    )
                }
            }
        }
    }

    // JavaScript bridge to capture metadata and playback events from Apple Music web
    inner class WebAppInterface(private val context: Context) {
        @JavascriptInterface
        fun onPlaybackUpdate(title: String, artist: String, album: String, isPlaying: Boolean) {
            runOnUiThread {
                val intent = Intent(context, PlaybackMediaSessionService::class.java).apply {
                    action = PlaybackMediaSessionService.ACTION_UPDATE_METADATA
                    putExtra(PlaybackMediaSessionService.EXTRA_TITLE, title)
                    putExtra(PlaybackMediaSessionService.EXTRA_ARTIST, artist)
                    putExtra(PlaybackMediaSessionService.EXTRA_ALBUM, album)
                    putExtra(PlaybackMediaSessionService.EXTRA_IS_PLAYING, isPlaying)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Completely eliminate the top blue bar / ActionBar
        supportActionBar?.hide()

        // 2. Enable True Edge-to-Edge Full Screen
        WindowCompat.setDecorFitsSystemWindows(window, false)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        progressBar = findViewById(R.id.progressBar)

        // 3. Hardware Acceleration Layer for 60/120 FPS ultra-smooth rendering
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        // 4. Aggressive Caching & High-Performance Settings
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            
            // High performance cache mode
            cacheMode = WebSettings.LOAD_CACHE_ELSE_NETWORK // Maximum snappy response, loads offline if cached
            
            // Allow media autoplay without user gesture (seamless music playback)
            mediaPlaybackRequiresUserGesture = false
            loadsImagesAutomatically = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            displayZoomControls = false

            // Allocate aggressive disk cache path (Up to 1024MB)
            val appCacheDir = File(applicationContext.cacheDir, "snappy_cache")
            if (!appCacheDir.exists()) {
                appCacheDir.mkdirs()
            }
            
            // Custom modern mobile user agent
            userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        }

        // Add JavaScript Interface bridge for background lock screen controls
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidMediaBridge")

        // Enable third-party cookies for cross-origin audio streams
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        // 5. WebView Clients with caching & background media session hook
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                if (newProgress < 100) {
                    progressBar.visibility = View.VISIBLE
                    progressBar.progress = newProgress
                } else {
                    progressBar.visibility = View.GONE
                }
            }
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                return false // Stay in WebView
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                progressBar.visibility = View.GONE

                // Inject hook into HTML5 audio/video and navigator.mediaSession
                injectMediaSessionListener()
            }
        }

        // Start initial background media playback service (MediaSessionService)
        if (true) {
            val startIntent = Intent(this, PlaybackMediaSessionService::class.java).apply {
                action = PlaybackMediaSessionService.ACTION_UPDATE_METADATA
                putExtra(PlaybackMediaSessionService.EXTRA_TITLE, "Apple Music ")
                putExtra(PlaybackMediaSessionService.EXTRA_ARTIST, "Apple Music")
                putExtra(PlaybackMediaSessionService.EXTRA_IS_PLAYING, true)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(startIntent)
            } else {
                startService(startIntent)
            }
        }

        // Register media action receiver for lock screen transport controls
        val filter = IntentFilter().apply {
            addAction(PlaybackMediaSessionService.ACTION_PLAY)
            addAction(PlaybackMediaSessionService.ACTION_PAUSE)
            addAction(PlaybackMediaSessionService.ACTION_NEXT)
            addAction(PlaybackMediaSessionService.ACTION_PREV)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(mediaActionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(mediaActionReceiver, filter)
        }

        // 6. Load Target Web Content (Edge-to-Edge with Cover Only focus)
        webView.loadUrl("https://beta.music.apple.com/in/new")
    }

    private fun injectMediaSessionListener() {
        val script = """
            (function() {
                function syncState() {
                    const audio = document.querySelector('audio, video');
                    const isPlaying = audio ? !audio.paused : true;
                    let title = document.title || 'Apple Music';
                    let artist = 'Streaming';
                    let album = 'Apple Music ';

                    if (navigator.mediaSession && navigator.mediaSession.metadata) {
                        title = navigator.mediaSession.metadata.title || title;
                        artist = navigator.mediaSession.metadata.artist || artist;
                        album = navigator.mediaSession.metadata.album || album;
                    }

                    if (window.AndroidMediaBridge) {
                        window.AndroidMediaBridge.onPlaybackUpdate(title, artist, album, isPlaying);
                    }
                }

                document.addEventListener('play', syncState, true);
                document.addEventListener('pause', syncState, true);
                setInterval(syncState, 2000);
            })();
        """.trimIndent()
        webView.evaluateJavascript(script, null)
    }

    // =========================================================================
    // CRITICAL FOR BACKGROUND PLAYBACK:
    // DO NOT call webView.onPause() or webView.pauseTimers()!
    // Normal Android apps call webView.onPause() which stops web audio immediately.
    // By keeping WebView active and running inside the Foreground Service,
    // audio continues playing seamlessly when minimized or screen is locked.
    // =========================================================================

    override fun onPause() {
        super.onPause()
        // Intentionally do NOT pause WebView timers or audio!
    }

    override fun onStop() {
        super.onStop()
        // Intentionally keep WebView alive for background streaming
    }

    override fun onDestroy() {
        unregisterReceiver(mediaActionReceiver)
        val stopIntent = Intent(this, PlaybackMediaSessionService::class.java)
        stopService(stopIntent)
        webView.destroy()
        super.onDestroy()
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
