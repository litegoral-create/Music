package com.applemusic.snappy

import android.app.PendingIntent
import android.content.Intent
import android.os.PowerManager
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

class PlaybackMediaSessionService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var player: ExoPlayer
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        const val ACTION_PLAY = "com.applemusic.snappy.ACTION_PLAY"
        const val ACTION_PAUSE = "com.applemusic.snappy.ACTION_PAUSE"
        const val ACTION_NEXT = "com.applemusic.snappy.ACTION_NEXT"
        const val ACTION_PREV = "com.applemusic.snappy.ACTION_PREV"
        const val ACTION_UPDATE_METADATA = "com.applemusic.snappy.ACTION_UPDATE_METADATA"

        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_ARTIST = "extra_artist"
        const val EXTRA_ALBUM = "extra_album"
        const val EXTRA_IS_PLAYING = "extra_is_playing"
    }

    override fun onCreate() {
        super.onCreate()

        // 1. Partial WakeLock ensures CPU runs when phone screen is turned off / locked
        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Apple Music :WakeLock").apply {
            setReferenceCounted(false)
            acquire(2 * 60 * 60 * 1000L) // 2 hours
        }

        // 2. Setup audio attributes with USAGE_MEDIA to request audio focus
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus= */ true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .setHandleAudioBecomingNoisy(true)
            .build()

        // 3. Connect open activity intent for lock screen / notification tap
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 4. Initialize MediaSession with modern Media3 MediaSession
        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(pendingIntent)
            .setCallback(CustomMediaSessionCallback())
            .build()
    }

    private inner class CustomMediaSessionCallback : MediaSession.Callback {
        override fun onPlaybackResumption(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo
        ): ListenableFuture<MediaSession.ConnectionResult> {
            sendBroadcast(Intent(ACTION_PLAY))
            return super.onPlaybackResumption(mediaSession, controller)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        intent?.let {
            when (it.action) {
                ACTION_PLAY -> {
                    player.play()
                    sendBroadcast(Intent(ACTION_PLAY))
                }
                ACTION_PAUSE -> {
                    player.pause()
                    sendBroadcast(Intent(ACTION_PAUSE))
                }
                ACTION_NEXT -> sendBroadcast(Intent(ACTION_NEXT))
                ACTION_PREV -> sendBroadcast(Intent(ACTION_PREV))
                ACTION_UPDATE_METADATA -> {
                    val title = it.getStringExtra(EXTRA_TITLE) ?: "Apple Music"
                    val artist = it.getStringExtra(EXTRA_ARTIST) ?: "Streaming Audio"
                    val album = it.getStringExtra(EXTRA_ALBUM) ?: "Apple Music "
                    val isPlaying = it.getBooleanExtra(EXTRA_IS_PLAYING, true)

                    // Update media metadata for lock screen & notification controls
                    val metadata = MediaMetadata.Builder()
                        .setTitle(title)
                        .setArtist(artist)
                        .setAlbumTitle(album)
                        .build()

                    val mediaItem = MediaItem.Builder()
                        .setMediaMetadata(metadata)
                        .build()

                    player.setMediaItem(mediaItem)
                    if (isPlaying) {
                        player.play()
                    } else {
                        player.pause()
                    }
                }
            }
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        wakeLock?.let { if (it.isHeld) it.release() }
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }
}
