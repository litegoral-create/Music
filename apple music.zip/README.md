# Apple Music  - Fullscreen Edge-to-Edge Android APK with MediaSessionService

This Android project is pre-configured to:
1. **Completely eliminate the top blue bar** using `Theme.MaterialComponents.DayNight.NoActionBar`.
2. **True Edge-to-Edge Content**: Content seamlessly covers the entire display without system headers.
3. **Background Playback & Lock Screen Controls**:
   - Audio continues playing when the app is minimized or the screen is locked.
   - Modern `PlaybackMediaSessionService` implementing AndroidX Media3 `MediaSessionService`.
   - Declares `FOREGROUND_SERVICE_MEDIA_PLAYBACK` and `FOREGROUND_SERVICE` permissions.
   - Rich media controls (Play/Pause, Skip, Previous) directly in the Android Notification shade and on the Lock Screen.
   - Partial WakeLock ensures CPU doesn't sleep while playing.
4. **Aggressive Caching**: `LOAD_CACHE_ELSE_NETWORK` + 1024MB disk cache pool for instantaneous screen loading.
5. **Hardware Acceleration**: Enabled for fluid 60/120 FPS scrolling.

## 🚀 How to Build the Finished .apk:

### Method 1: Instant Cloud Build (No Android Studio Needed!)
1. Create a free repository on GitHub and upload these files.
2. Go to the **Actions** tab in your GitHub repository.
3. Run the **"Build Android APK"** workflow.
4. When finished (takes ~60 seconds), click on **Artifacts** to download your ready-to-install `Apple Music _Finished.apk` directly!

### Method 2: Android Studio (Local Compilation)
1. Open Android Studio.
2. Select **File > Open...** and select this extracted folder.
3. Wait for Gradle sync to complete.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will notify you with a link to your freshly compiled `app-debug.apk`!
